<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تقرير جديد - إنضباط</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <nav class="bg-blue-600 text-white p-4">
        <div class="container mx-auto flex justify-between items-center">
            <h1 class="text-xl font-bold">تقرير جديد</h1>
            <a href="<?php echo e(route('dashboard')); ?>" class="bg-gray-500 hover:bg-gray-600 px-3 py-1 rounded">رجوع</a>
        </div>
    </nav>

    <div class="container mx-auto p-4">
        <div class="bg-white p-6 rounded-lg shadow">
            <h2 class="text-xl font-bold mb-4">تقرير عن: <?php echo e($eleve->nom_ar); ?> <?php echo e($eleve->prenom_ar); ?></h2>
            
            <form method="POST" action="<?php echo e(route('rapport.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="eleve_id" value="<?php echo e($eleve->id); ?>">
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">تاريخ الحصة</label>
                        <input type="date" name="date_seance" required 
                               class="mt-1 block w-full border border-gray-300 rounded-md p-2"
                               value="<?php echo e(old('date_seance', now()->format('Y-m-d'))); ?>">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">وقت الحصة</label>
                        <input type="time" name="heure_seance" required 
                               class="mt-1 block w-full border border-gray-300 rounded-md p-2"
                               value="<?php echo e(old('heure_seance', now()->format('H:i'))); ?>">
                    </div>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">المادة</label>
                    <input type="text" name="matiere" required 
                           class="mt-1 block w-full border border-gray-300 rounded-md p-2"
                           value="<?php echo e(old('matiere', auth()->user()->matiere)); ?>">
                    <?php $__errorArgs = ['matiere'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">السلوكيات <span class="text-red-500">*</span></label>
                    
                    <!-- Affichage du total des points en temps réel -->
                    <div class="mb-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div class="flex justify-between items-center">
                            <span class="font-medium text-yellow-800">إجمالي النقاط المخصومة:</span>
                            <span id="total-points" class="text-xl font-bold text-red-600">0.00</span>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-2" id="comportements-container">
                        <?php $__currentLoopData = $comportements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comportement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center p-2 border border-gray-200 rounded hover:bg-gray-50 comportement-item">
                            <input type="checkbox" name="comportements[]" value="<?php echo e($comportement->id); ?>" 
                                   class="ml-2 comportement-checkbox" 
                                   data-points="<?php echo e($comportement->points_retires); ?>"
                                   data-nom-fr="<?php echo e($comportement->nom_fr); ?>">
                            <span class="flex-1"><?php echo e($comportement->nom_ar); ?></span>
                            <span class="text-xs bg-red-100 text-red-800 px-2 py-1 rounded">
                                -<?php echo e(number_format($comportement->points_retires, 2)); ?>

                            </span>
                        </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php $__errorArgs = ['comportements'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700">ملاحظات إضافية</label>
                    <textarea name="notes_additionnelles" rows="4" 
                              class="mt-1 block w-full border border-gray-300 rounded-md p-2"
                              placeholder="أضف أي ملاحظات إضافية هنا..."><?php echo e(old('notes_additionnelles')); ?></textarea>
                </div>

                <!-- Champ caché pour les points totaux -->
                <input type="hidden" name="points_retires" id="points-retires-input" value="0">

                <button type="submit" 
                        class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                    إرسال التقرير
                </button>
            </form>
        </div>
    </div>

    <script>
        // Calcul du total des points en temps réel
        document.addEventListener('DOMContentLoaded', function() {
            const checkboxes = document.querySelectorAll('.comportement-checkbox');
            const totalPointsElement = document.getElementById('total-points');
            const pointsRetiresInput = document.getElementById('points-retires-input');
            
            function updateTotalPoints() {
                let total = 0.0;
                
                checkboxes.forEach(checkbox => {
                    if (checkbox.checked) {
                        total += parseFloat(checkbox.getAttribute('data-points'));
                    }
                });
                
                // Afficher avec 2 décimales
                totalPointsElement.textContent = total.toFixed(2);
                pointsRetiresInput.value = total.toFixed(2);
                // Changer la couleur si le total est élevé
                if (total > 5) {
                    totalPointsElement.className = 'text-xl font-bold text-red-600';
                } else if (total > 0) {
                    totalPointsElement.className = 'text-xl font-bold text-orange-600';
                } else {
                    totalPointsElement.className = 'text-xl font-bold text-gray-600';
                }
            }
            
            // Ajouter l'événement à chaque checkbox
            checkboxes.forEach(checkbox => {
                checkbox.addEventListener('change', updateTotalPoints);
            });
            
            // Initialiser le calcul
            updateTotalPoints();
        });
    </script>
</body>
</html><?php /**PATH C:\wamp64\www\indibat\resources\views/rapports/create.blade.php ENDPATH**/ ?>